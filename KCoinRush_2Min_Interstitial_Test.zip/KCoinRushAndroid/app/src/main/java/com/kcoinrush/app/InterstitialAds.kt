package com.kcoinrush.app

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Interstitial test ads. The official Google test unit is used until the app
 * has been fully tested and is ready for production.
 */
object InterstitialAds {
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    private var cachedAd: InterstitialAd? = null
    private var isLoading = false

    fun load(context: Context) {
        if (cachedAd != null || isLoading) return
        isLoading = true
        InterstitialAd.load(
            context,
            TEST_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    isLoading = false
                    cachedAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoading = false
                    cachedAd = null
                }
            }
        )
    }

    fun show(
        activity: Activity,
        onShown: () -> Unit = {},
        onUnavailable: () -> Unit = {}
    ) {
        val ad = cachedAd
        if (ad == null) {
            load(activity.applicationContext)
            onUnavailable()
            return
        }

        cachedAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                onShown()
            }

            override fun onAdDismissedFullScreenContent() {
                load(activity.applicationContext)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                load(activity.applicationContext)
            }
        }
        ad.show(activity)
    }
}
