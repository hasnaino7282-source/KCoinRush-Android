# KCoinRush Android prototype

This is a native Android project written in Kotlin with Jetpack Compose. It is not a Telegram mini app or a website wrapper.

## Included in this first prototype
- Premium dark / purple / gold interface
- Four playable mini-games: Coin Rush, Memory Challenge, Brain Challenge, Gold Runner
- Local coin balance, XP, level progression (up to level 100)
- A simple three-game daily mission bonus
- Local progress persistence using Android SharedPreferences

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

For a Google Play release, create a signed Android App Bundle (AAB) in Android Studio. Do not publish this prototype as a finished rewards app yet.

## Important prototype limitations
- Coins are virtual, non-cash game points only.
- Progress is stored only on this device. There are no real accounts, cloud sync, referrals, leaderboard, AdMob ads, or server-side anti-cheat yet.
- The games and reward amounts are a prototype and need playtesting and balancing.
- The app has not been compiled or tested on a device in this environment.

## Next development milestones
1. Test and polish gameplay, accessibility, and screen sizes.
2. Add backend authentication and cloud save (e.g. Firebase).
3. Add server-validated missions/referrals and anti-cheat.
4. Integrate Google Mobile Ads rewarded ads with real ad unit IDs and consent handling.
5. Configure signing, privacy policy, Data safety disclosures, and Play Console testing.

## Build APK from GitHub (useful if you only have a phone)
The included GitHub Actions workflow builds a **debug APK** when you push to the `main` branch or run it manually. In your repository, open **Actions** → **Build KCoinRush Android prototype** → select the latest successful run → download the `KCoinRush-debug-apk` artifact. This APK is for testing only, not the final Play Store release.
