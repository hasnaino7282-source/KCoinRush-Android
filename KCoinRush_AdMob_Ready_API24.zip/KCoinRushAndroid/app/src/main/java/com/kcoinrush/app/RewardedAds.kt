package com.kcoinrush.app

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.OnUserEarnedRewardListener

/**
 * Rewarded-ad helper. Uses Google's official test ad unit during development.
 * Replace with the KCoinRush live ad unit only after test builds are verified
 * and the app is ready for production.
 */
object RewardedAds {
    private const val TEST_REWARDED_AD_UNIT_ID =
        "ca-app-pub-3940256099942544/5224354917"

    fun load(
        context: Context,
        onLoaded: () -> Unit = {},
        onFailed: (String) -> Unit = {}
    ) {
        RewardedAd.load(
            context,
            TEST_REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    cachedAd = ad
                    onLoaded()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    cachedAd = null
                    onFailed(error.message)
                }
            }
        )
    }

    private var cachedAd: RewardedAd? = null

    fun show(
        activity: Activity,
        onRewardEarned: (amount: Int, rewardType: String) -> Unit,
        onUnavailable: () -> Unit = {}
    ) {
        val ad = cachedAd
        if (ad == null) {
            onUnavailable()
            return
        }
        cachedAd = null
        ad.show(activity, OnUserEarnedRewardListener { reward ->
            onRewardEarned(reward.amount, reward.type)
        })
    }
}
