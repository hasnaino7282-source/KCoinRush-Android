package com.kcoinrush.app

import android.app.Application
import com.google.android.gms.ads.MobileAds

class KCoinRushApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this)
    }
}
