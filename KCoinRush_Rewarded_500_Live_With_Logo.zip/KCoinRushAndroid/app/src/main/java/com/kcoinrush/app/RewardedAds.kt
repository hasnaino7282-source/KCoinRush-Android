package com.kcoinrush.app

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.OnUserEarnedRewardListener

/**
 * Rewarded-ad helper. Uses Google's official test ad unit during development.
 * Coins are granted by the app only from the earned-reward callback.
 */
object RewardedAds {
    private const val LIVE_REWARDED_AD_UNIT_ID =
        "ca-app-pub-1389085666595852/8645053337"

    private var cachedAd: RewardedAd? = null

    fun load(
        context: Context,
        onLoaded: () -> Unit = {},
        onFailed: (String) -> Unit = {}
    ) {
        RewardedAd.load(
            context,
            LIVE_REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    cachedAd = ad
                    onLoaded()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    cachedAd = null
                    onFailed(error.message)
                }
            }
        )
    }

    fun show(
        activity: Activity,
        onRewardEarned: (amount: Int, rewardType: String) -> Unit,
        onAdClosed: () -> Unit = {},
        onUnavailable: () -> Unit = {}
    ) {
        val ad = cachedAd
        if (ad == null) {
            onUnavailable()
            return
        }
        cachedAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                onAdClosed()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                onAdClosed()
            }
        }
        ad.show(activity, OnUserEarnedRewardListener { reward ->
            onRewardEarned(reward.amount, reward.type)
        })
    }
}
